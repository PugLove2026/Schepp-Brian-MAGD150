function setup() {
  createCanvas(400, 400);
  background(30);
  fill(250)
  circle(330, 50, 90)
  strokeWeight(6)
  fill(70)
  rect(10,60,50,340)
  rect(90,20,90,380)
  rect(200,30,70,370)
  fill(130)
  rect(70,100,50,300)
  rect(130,50,80,350)
  rect(230,90,70,310)
  rect(330,50,60,350)
  fill(200)
  rect(30,200,50,200)
  rect(90,150,80,250)
  rect(190,170,55,230)
  rect(280,110,70,290)
  fill(240)
  rect(70,230,70,170)
  rect(160,280,50,130)
  rect(240,250,70,150)
}
function draw() {
}