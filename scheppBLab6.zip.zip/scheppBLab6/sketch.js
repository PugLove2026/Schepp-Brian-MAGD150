let snowY = []

function setup() 
{
  createCanvas(400, 400);
  colorMode(RGB)
  for(let i = 0; i < 20000; i++)
  {
    snowY[i] = random(300,-10000)
  }
   console.log(snowY)
}

function draw() 
{
  background(100,220,255,255)
  fill(240)
  rect(0,300,400,100)
  fill(255)
  //body
  circle(200,350,95)
  circle(200,290,75)
  //head
  circle(200,240,55)
  //buttons
  fill(100)
  circle(200,280,10)
  circle(200,295,10)
  //eyes
  fill(100)
  circle(190,230,10)
  circle(210,230,10)
  //nose
  fill(255,165,0,255)
  triangle(200,240,200,250,240,245)
  //snowflakes
  fill(255)
  for (let i = 0; i < snowY.length; i++) 
  {
    snowY[i] += 1.75
    let x = i * 0.3
    circle(x,snowY[i],4)
  }
}