let galacticLegends = ["Ahsoka Tano", "Pirate King Hondo Ohnaka", "Leia Organa", "Jabba the Hutt", "Lord Vader", "Jedi Master Kenobi","Jedi Master Luke Skywalker", "Sith Eternal Emperor", "Supreme Leader Kylo Ren", "Rey", "The Mandalorian and Grogu"]
let teamOne = []
let teamTwo = []
let teamsCombined = []
function setup() 
{
  createCanvas(700, 400);
  background(220)
  for(let i = 0; i<5; i++)
  {
    let gl = Math.floor(random(0,galacticLegends.length))
    teamOne.push(galacticLegends[gl])
    galacticLegends.splice(gl,1)
    
    gl = Math.floor(random(0,galacticLegends.length))
    teamTwo.push(galacticLegends[gl])
    galacticLegends.splice(gl,1)

    teamsCombined = teamOne.concat(teamTwo)
  }
  text("Array 1: " + teamOne.join(", "), 10, 50)
  text("Array 2: " + teamTwo.join(", "), 10, 100)
  text("Random 1: " + teamOne [Math.floor(random(0,teamOne.length))], 10, 150)
  text("Random 2: " + teamTwo [Math.floor(random(0,teamTwo.length))], 10, 200)
  text("Random 1 & 2: " + teamsCombined [Math.floor(random(0,teamsCombined.length))], 10, 250 )
  
}

